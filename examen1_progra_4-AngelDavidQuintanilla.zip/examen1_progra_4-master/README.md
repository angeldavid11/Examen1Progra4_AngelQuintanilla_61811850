## Código fuente del proyecto para el Examen 1 Programación 4
## Autor: Ing. Yamil Uclés.

# Ejecute el comando:
```
npm install
```

### Instrucciones: 
## Deberá crear el método get para producto (Valor 5 puntos).
## Deberá crear el método post para producto (Valor 5 puntos).
## Deberá definir el esquema para el modelo Producto (Valor 5 puntos).
## Subir el proyecto a github con la nomenclatura: examen1_progra4_nombre_#cuenta (5 puntos).
