const express = require('express');

const Producto = require('../models/producto');

const app = express();

app.get('/', (req, res) => {
    res.json('Examen 1 Programación 4');
});

// Deberá hacer aquí el método get para producto (Valor 5 puntos)
app.get('/Producto', (req, res) =>{
    res.json('get Producto');
});

// Deberá hacer aquí el método post para producto (Valor 5 puntos)
app.post('/Producto', (req, res) =>{
    let body = req.body;

    let Producto = new Producto({//crea nueva instancia del esquema Producto
        nombre: body.nombre,
        precio: body.precio,
        creado_en : body.Creado_en
        
    });