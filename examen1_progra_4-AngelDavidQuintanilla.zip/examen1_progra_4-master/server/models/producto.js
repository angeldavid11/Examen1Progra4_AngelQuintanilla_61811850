const mongoose = require('mongoose');

let Schema = mongoose.Schema;

//Definir el esquema para el modelo Producto (Valor 5 puntos)
let Producto = new Schema ({
    nombre: {
        type:String,
        required:[true,`El nombre es necesario`]
    },
    
     precio:{
         type: Number,
         required:[true,`El Precio del producto es necesario`]
     },
     creado_en:{
         type: Date,
         default: Date.now
        }
});


module.exports = mongoose.model('Producto', usuarioSchema);